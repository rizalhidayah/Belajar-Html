<?php
// $siswa = (object)[
//   'nama'  => "naufal",
//   'kelas' => "12A"
// ];

// $siswa[0] = "HALO";
// $siswa[1] = "HALO BRO";

echo json_encode($siswa);

 ?>
