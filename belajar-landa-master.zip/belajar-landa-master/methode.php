<?php echo $_POST['angka']; ?>

<!DOCTYPE html>
<html lang="en" dir="ltr">
  <head>
    <meta charset="utf-8">
    <title></title>
  </head>
  <body>
    <form class="" action="" method="post">
      <input type="text" name="angka" value="">
      <button type="submit" name="button" value="submit">
        Submit Bro!
      </button>
    </form>
  </body>
</html>
