<?php

echo "ini adalah halama profil ".$_GET['nama'];

 ?>
