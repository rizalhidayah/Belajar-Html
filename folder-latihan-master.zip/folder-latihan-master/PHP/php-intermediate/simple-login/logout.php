<?php

session_start();

// session_unset($_SESSION['data_user']);

session_destroy(); // Menghancurkan semua session 

 ?>
