<?php

// include 'template/header.php';
// require('template/header.php');
require 'template/header.php';

 ?>

    <main>
      <form>
        <label for="">Nama</label>
        <input type="text" name="name" value="">
        <br>

        <label for="">Pesan</label>
        <textarea name="name" rows="8" cols="40"></textarea>
        <br>

        <input type="submit" name="submit" value="">
      </form>
    </main>

<?php require 'template/footer.php'; ?>
