<?php

// include 'template/header.php';
// require('template/header.php');
require 'template/header.php';

 ?>
    <main>
      <h2>About Me</h2>
      <p>Selamat datang di halaman tentang saya</p>
    </main>

<?php require 'template/footer.php'; ?>
