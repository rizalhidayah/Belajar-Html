<footer>
  &copy; Belajar Koding 2017
</footer>
</body>
</html>
