<!DOCTYPE html>
<html>
  <head>
    <meta charset="utf-8">
    <title>Belajar PHP</title>
  </head>
  <body>
    <header>
      <h1>Belajar Koding Gampang</h1>
    </header>

    <nav>
        <li><a href="index.php">home</a></li>
        <li><a href="kontak.php">kontak</a></li>
        <li><a href="about.php">about</a></li>
    </nav>
