﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ceiling___floor___round
{
    class Program
    {
        static void Main(string[] args)
        {
            double angka = 3.45;
            Console.WriteLine(Math.Ceiling(angka));
            Console.WriteLine(Math.Floor(angka));
            Console.WriteLine(Math.Round(angka));
        }
    }
}
