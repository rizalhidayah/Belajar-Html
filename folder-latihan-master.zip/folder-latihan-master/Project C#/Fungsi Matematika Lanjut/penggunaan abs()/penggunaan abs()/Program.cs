﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace penggunaan_abs__
{
    class Program
    {
        static void Main(string[] args)
        {
            // Gunanya untuk membuat nilai absolute (nilai mutlak)
            int A = int.Parse(Console.ReadLine());
            Console.WriteLine(Math.Abs(A));
        }
    }
}
