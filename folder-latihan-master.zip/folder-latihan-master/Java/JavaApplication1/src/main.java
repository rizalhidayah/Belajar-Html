public class main {
    
    String name = "oercobaan";
    
    String names() {
         return "Tampilkan";
        
    }
    
    public static void main(String[] args) {
        
        main nama = new main();
        nama.names();
        
        System.out.println(nama.names());
    }
    
}
